<p align="center"><a href="https://xugaoyi.com/" target="_blank" rel="noopener noreferrer"><img width="180" src="https://fastly.jsdelivr.net/gh/xugaoyi/image_store/blog/20200409124835.png" alt="logo"></a></p>


<h2 align="center">vuepress-theme-vdoing</h2>

[在线文档(国内源)](https://doc.xugaoyi.com/)

[主题仓库](https://github.com/xugaoyi/vuepress-theme-vdoing)

[本仓库的gitee镜像](https://gitee.com/xugaoyi/vuepress-theme-vdoing-doc)
