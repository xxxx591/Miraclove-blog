cqjs.editor('html', {
    extends: "editors.text",
});