import './widgets/JComponent.js';
import './widgets/JDialog.js';
import './home/JFrame.js';
import './home/JFullScreen.js';
import './home/JIconLib.js';
import './home/JMenu.js';
import './home/JMenuSearch.js';
import './home/JCompany.js';
import './home/JWebApp.js';

