cqjs.column('many2many', {
    extends:'columns.one2many'
});
cqjs.column('many2many_tags', {
    extends:'columns.one2many'
});